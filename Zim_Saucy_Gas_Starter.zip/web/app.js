const PRICE_PER_KG = 2;
const KEY = "zimSaucyGas.v1";
const $ = (id) => document.getElementById(id);
let state = { stockKg: 0, totalReceivedKg: 0, sales: [] };

function load() {
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || "null");
    if (saved && typeof saved === "object") state = {...state, ...saved};
  } catch (_) {}
}
function save() { localStorage.setItem(KEY, JSON.stringify(state)); }
function num(n) { return Number(n).toLocaleString("en-US",{maximumFractionDigits:3}); }
function money(n) { return "$" + Number(n).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2}); }
function sameDay(a,b) {
  const x = new Date(a), y = new Date(b);
  return x.getFullYear()===y.getFullYear() && x.getMonth()===y.getMonth() && x.getDate()===y.getDate();
}
function todaySales() { return state.sales.filter(s => sameDay(s.time, Date.now())); }
function render() {
  const today = todaySales();
  const total = today.reduce((s,x)=>s+x.amount,0);
  const kg = today.reduce((s,x)=>s+x.kg,0);
  $("stock").textContent = `${num(state.stockKg)} kg`;
  $("todayMoney").textContent = money(total);
  $("todayKg").textContent = `${num(kg)} kg`;
  $("todayCount").textContent = `${today.length} sales`;
  $("reportMoney").textContent = money(total);
  $("reportKg").textContent = `${num(kg)} kg`;
  $("reportCount").textContent = today.length;
  $("todayDate").textContent = new Date().toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"});
  const history = $("history");
  if (!state.sales.length) { history.className="history empty"; history.textContent="No sales recorded yet."; return; }
  history.className="history";
  history.innerHTML = state.sales.slice(0,20).map(s => {
    const when = new Date(s.time).toLocaleString(undefined,{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"});
    return `<div class="saleitem"><div><b>${when}</b><small>${num(s.kg)} kg sold</small></div><div class="saleamount"><b>${money(s.amount)}</b><small>Sale</small></div></div>`;
  }).join("");
}
$("amountInput").addEventListener("input", () => {
  const amount = Number($("amountInput").value) || 0;
  $("kgPreview").textContent = `${num(amount / PRICE_PER_KG)} kg`;
});
$("stockForm").addEventListener("submit", e => {
  e.preventDefault();
  const kg = Number($("stockInput").value);
  if (!Number.isFinite(kg) || kg <= 0) return;
  state.stockKg += kg; state.totalReceivedKg += kg; save(); render();
  $("stockInput").value = ""; $("message").textContent = `${num(kg)} kg added to stock.`;
});
$("saleForm").addEventListener("submit", e => {
  e.preventDefault();
  const amount = Number($("amountInput").value);
  if (!Number.isFinite(amount) || amount <= 0) { $("message").textContent="Enter an amount greater than zero."; return; }
  const kg = amount / PRICE_PER_KG;
  if (kg > state.stockKg + 1e-9) { $("message").textContent=`Not enough stock. Available: ${num(state.stockKg)} kg.`; return; }
  state.stockKg = Math.max(0,state.stockKg-kg);
  state.sales.unshift({amount,kg,time:Date.now()});
  save(); render(); $("amountInput").value=""; $("kgPreview").textContent="0 kg";
  $("message").textContent=`Sale saved: ${money(amount)} for ${num(kg)} kg.`;
});
$("exportBtn").addEventListener("click", () => {
  const rows = [["Date","Amount USD","Kilograms sold"],...state.sales.map(s=>[new Date(s.time).toISOString(),s.amount,s.kg])];
  const csv = rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\n");
  const blob = new Blob([csv],{type:"text/csv"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href=url; a.download="zim-saucy-gas-sales.csv"; a.click();
  URL.revokeObjectURL(url);
});
load(); render();
