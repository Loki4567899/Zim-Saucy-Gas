plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "zw.zimsaucygas.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "zw.zimsaucygas.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
