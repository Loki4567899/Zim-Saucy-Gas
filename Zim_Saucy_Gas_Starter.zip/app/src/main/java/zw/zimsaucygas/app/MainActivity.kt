package zw.zimsaucygas.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("zim_saucy_gas", MODE_PRIVATE) }
    private var stockKg = 0.0
    private var totalReceivedKg = 0.0
    private val sales = mutableListOf<Sale>()

    private lateinit var stockLabel: TextView
    private lateinit var todaySalesLabel: TextView
    private lateinit var todayKgLabel: TextView
    private lateinit var historyLabel: TextView
    private lateinit var statusLabel: TextView

    data class Sale(val amount: Double, val kg: Double, val timestamp: Long)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        render()
    }

    private fun loadData() {
        stockKg = prefs.getString("stock", "0")?.toDoubleOrNull() ?: 0.0
        totalReceivedKg = prefs.getString("received", "0")?.toDoubleOrNull() ?: 0.0
        val raw = prefs.getString("sales", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                sales.add(Sale(item.getDouble("amount"), item.getDouble("kg"), item.getLong("time")))
            }
        } catch (_: Exception) { }
    }

    private fun saveData() {
        val arr = JSONArray()
        sales.forEach {
            arr.put(JSONObject().put("amount", it.amount).put("kg", it.kg).put("time", it.timestamp))
        }
        prefs.edit()
            .putString("stock", stockKg.toString())
            .putString("received", totalReceivedKg.toString())
            .putString("sales", arr.toString())
            .apply()
    }

    private fun render() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(24))
            setBackgroundColor(0xFFF5F6F8.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(page)

        page.addView(text("ZIM SAUCY GAS", 27, true, 0xFF172033.toInt()))
        page.addView(text("Sales & stock manager  •  USD", 14, false, 0xFF667085.toInt()))
        page.addView(space(16))

        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        stockLabel = text("", 22, true, 0xFF087443.toInt())
        todaySalesLabel = text("", 17, true, 0xFF172033.toInt())
        todayKgLabel = text("", 15, false, 0xFF475467.toInt())
        stats.addView(panel(stockLabel))
        stats.addView(panel(todaySalesLabel))
        stats.addView(panel(todayKgLabel))
        page.addView(stats)
        page.addView(space(16))

        page.addView(sectionTitle("ADD NEW STOCK"))
        val stockInput = numberInput("Kilograms received (e.g. 100)")
        page.addView(stockInput)
        page.addView(actionButton("Add stock", 0xFF087443.toInt()) {
            val kg = stockInput.text.toString().trim().toDoubleOrNull()
            if (kg == null || kg <= 0) {
                showStatus("Enter a stock quantity greater than zero.")
            } else {
                stockKg += kg
                totalReceivedKg += kg
                saveData()
                stockInput.setText("")
                showStatus("${fmt(kg)} kg added to stock.")
                refreshStats()
            }
        })

        page.addView(space(18))
        page.addView(sectionTitle("RECORD A SALE"))
        page.addView(text("Fixed selling price: $2.00 per kg", 14, true, 0xFF344054.toInt()))
        val saleInput = numberInput("Amount customer paid in USD")
        page.addView(saleInput)
        val calc = text("Customer receives: 0.000 kg", 15, true, 0xFF087443.toInt())
        page.addView(calc)
        saleInput.addTextChangedListener(SimpleWatcher {
            val amount = saleInput.text.toString().toDoubleOrNull() ?: 0.0
            calc.text = "Customer receives: ${fmt(amount / 2.0)} kg"
        })
        page.addView(actionButton("Record sale", 0xFF175CD3.toInt()) {
            val amount = saleInput.text.toString().trim().toDoubleOrNull()
            if (amount == null || amount <= 0) {
                showStatus("Enter an amount greater than zero.")
            } else {
                val kg = amount / 2.0
                if (kg > stockKg + 0.0000001) {
                    showStatus("Not enough stock. Available: ${fmt(stockKg)} kg.")
                } else {
                    stockKg = (stockKg - kg).coerceAtLeast(0.0)
                    sales.add(0, Sale(amount, kg, System.currentTimeMillis()))
                    saveData()
                    saleInput.setText("")
                    showStatus("Sale saved: $${fmt(amount)} for ${fmt(kg)} kg.")
                    refreshStats()
                }
            }
        })

        page.addView(space(10))
        statusLabel = text("", 14, true, 0xFF087443.toInt())
        page.addView(statusLabel)
        page.addView(space(18))
        page.addView(sectionTitle("TODAY'S REPORT"))
        page.addView(text("Today's totals update automatically whenever you record a sale.", 13, false, 0xFF667085.toInt()))
        page.addView(space(14))
        page.addView(sectionTitle("RECENT SALES"))
        historyLabel = text("", 14, false, 0xFF344054.toInt())
        page.addView(panel(historyLabel))
        page.addView(space(16))
        page.addView(text("Your records are saved on this device. Export/backup can be added in a later version.", 12, false, 0xFF667085.toInt()))

        setContentView(scroll)
        refreshStats()
    }

    private fun refreshStats() {
        val today = sales.filter { isToday(it.timestamp) }
        val money = today.sumOf { it.amount }
        val kg = today.sumOf { it.kg }
        stockLabel.text = "Available stock: ${fmt(stockKg)} kg"
        todaySalesLabel.text = "Today's sales: $${fmt(money)}"
        todayKgLabel.text = "Today's gas sold: ${fmt(kg)} kg  •  ${today.size} sales"
        val recent = sales.take(12)
        historyLabel.text = if (recent.isEmpty()) "No sales recorded yet." else recent.joinToString("\n\n") {
            "${dateTime(it.timestamp)}   •   $${fmt(it.amount)}\n${fmt(it.kg)} kg sold"
        }
    }

    private fun isToday(timestamp: Long): Boolean {
        val a = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(timestamp))
        val b = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        return a == b
    }

    private fun dateTime(timestamp: Long): String =
        SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(timestamp))

    private fun fmt(value: Double): String = String.format(Locale.US, "%.3f", value).trimEnd('0').trimEnd('.').ifEmpty { "0" }

    private fun showStatus(message: String) {
        statusLabel.text = message
    }

    private fun text(value: String, size: Int, bold: Boolean, color: Int) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun sectionTitle(value: String) = text(value, 13, true, 0xFF667085.toInt()).apply {
        setPadding(0, dp(8), 0, dp(5))
    }

    private fun panel(child: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setBackgroundColor(0xFFFFFFFF.toInt())
        addView(child)
        val params = LinearLayout.LayoutParams(-1, -2)
        params.bottomMargin = dp(8)
        layoutParams = params
    }

    private fun numberInput(hintText: String) = EditText(this).apply {
        hint = hintText
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        textSize = 16f
        setSingleLine(true)
        setPadding(dp(12), dp(12), dp(12), dp(12))
        setBackgroundColor(0xFFFFFFFF.toInt())
        val params = LinearLayout.LayoutParams(-1, dp(52))
        params.bottomMargin = dp(8)
        layoutParams = params
    }

    private fun actionButton(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
        setOnClickListener { action() }
        val params = LinearLayout.LayoutParams(-1, dp(50))
        params.bottomMargin = dp(4)
        layoutParams = params
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun interface SimpleWatcher : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: android.text.Editable?) { run() }
        fun run()
    }
}
