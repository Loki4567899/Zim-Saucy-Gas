# Zim Saucy Gas

A simple sales and stock manager for gas sold by kilogram at a fixed price of **US$2.00/kg**.

## Best option if you only have an iPhone: use the web app
The `web/` folder contains an iPhone-friendly installable web app. It runs in Safari and can be added to your Home Screen. It also works offline after its first successful load.

### Publish it free with GitHub Pages
1. Download and unzip this project on your iPhone using the Files app.
2. In Safari, sign in at https://github.com and create a repository named `zim-saucy-gas`.
3. In the repository, choose **Add file → Upload files** and upload the contents of this project folder, preserving all folders, including `.github` and `web`.
4. Commit the files to the `main` branch.
5. Open **Settings → Pages** in the repository. Under Build and deployment, select **GitHub Actions** as the source.
6. Open the **Actions** tab and run **Deploy Zim Saucy Gas web app** if it has not started automatically.
7. When deployment succeeds, open the Pages URL shown in the workflow.
8. In iPhone Safari, tap **Share → Add to Home Screen**. It will appear like an app on your iPhone.

## Android APK option
The `app/` folder is a native Android starter project. The `Build Zim Saucy Gas APK` GitHub Actions workflow builds a debug APK. An APK cannot be installed on an iPhone; it must be transferred to an Android device.

## Features
- Add incoming gas stock in kilograms.
- Record each sale by entering the USD amount received.
- Calculate kilograms sold automatically: amount paid ÷ $2.
- Deduct sold kilograms from stock and prevent sales beyond available stock.
- Show today's money collected, kilograms sold, transaction count, and recent sales.
- Export sales history to CSV.

## Important
- The web app stores records locally in the browser on that device. It does not sync across devices or provide cloud backup. Use Export CSV regularly.
- This starter uses a fixed $2.00/kg selling price and does not yet calculate profit or track expenses.
- Test with sample data before using it for official business records.
- GitHub Pages and GitHub Actions are subject to GitHub's free-tier limits and account settings.
